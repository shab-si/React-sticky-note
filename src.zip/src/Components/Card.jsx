import React from "react";

export default function Card(props)
{

    return (
        <div className="col-md-4 col-sm-6 content-card">
            <div className="card-big-shadow">
                 <div className="card card-just-text" data-background="color" data-color= {props.color} data-radius="none">
                    <div className="content">
                        <a href={props.weblink} alt = "no">
                            <h6 className="category">{props.category}</h6>
                            <h4 className="title">{props.title}</h4>
                            <p className="description">{props.description}. </p>
                        </a>
                    </div>
                </div>
            </div>    
        </div>

    )
}