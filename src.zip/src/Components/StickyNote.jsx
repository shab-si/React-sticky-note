import React from "react";
import Card from './Card'

export default function StickyNote()
{
    const cardsData = [
        {color : 'blue', weblink : 'https://www.w3schools.com/', category : 'category #1',  title : 'title #1', description : 'description #1'},
        {color : 'green', weblink : 'www.mysite.com', category : 'category #2',  title : 'title #2', description : 'description #2'},
        {color : 'purple', weblink : '', category : 'category #3',  title : 'title #3', description : 'description #3'},
        {color : 'yellow', weblink : '', category : 'category #4',  title : 'title #4', description : 'description #4'},
    ]

    const myCards = cardsData.map(card => <Card color = {card.color} weblink ={card.weblink} category = {card.category} title = {card.title} description = {card.description} />)
    return (
        <div className="container bootstrap snippets bootdeys">
            <div className="row">
                {myCards}                               
            </div>
        </div>
    )
}

