
import './Styles.css';
import StickyNote from './Components/StickyNote';


function App() {
  return (
   <StickyNote />

     

  );
}

export default App;
